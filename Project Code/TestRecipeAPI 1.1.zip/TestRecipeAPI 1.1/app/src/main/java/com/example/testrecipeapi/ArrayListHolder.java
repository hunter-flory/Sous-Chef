package com.example.testrecipeapi;

import java.util.ArrayList;

public class ArrayListHolder {
    ArrayList<String> arr;

    public void putArrayList(ArrayList<String> array){
        arr = array;
    }

    public ArrayList<String> getArrayList(){
        return arr;
    }
}
