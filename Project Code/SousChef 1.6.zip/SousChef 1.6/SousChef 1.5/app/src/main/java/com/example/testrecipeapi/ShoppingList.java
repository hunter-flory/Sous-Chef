package com.example.testrecipeapi;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;

public class ShoppingList extends AppCompatActivity {
    // Create local shoppingList array and pass ingredientList
    ArrayList<String> shoppingList = DishSearch.ingredientList;
    // create protected key for shopping list in shared preferences
    protected String key = "ShoppingList";
    public void saveList(ArrayList<String> list, String key)
    {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();

        JSONArray savedList = new JSONArray(list);
        editor.putString(key, String.valueOf(shoppingList));
        editor.apply();
    }

    // loads previous saved shopping list
    public ArrayList<String> loadList(String key)
    {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String json = prefs.getString(key, null);
        ArrayList<String> loadedList = new ArrayList<String>(Arrays.asList(json.split("\n")));
        return loadedList;
    }
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoppinglist);


        final ListView shopView = findViewById(R.id.shopView);
        final Button deleteItem = findViewById(R.id.deleteItemBtn);
        final Button clearList = findViewById(R.id.clearListBtn);
        final Button saveList = findViewById(R.id.saveListBtn);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String value = prefs.getString(key, null);

        // call loadArrayList with key
        if(value == null){
            shoppingList.add("Shopping List is empty!");
        }
        else
        {
            shoppingList = loadList(key);
        }



        // Set shopView to display shoppingList items in selectable Listview
        // making this shopView(List View) selectable because I want user to be able
        // to select items and delete them once purchased or if they already have
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_selectable_list_item, shoppingList);
        shopView.setAdapter(arrayAdapter);
        shopView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                // User clicks item they wish to delete, then clicks 'delete item'
                deleteItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        shoppingList.remove(i);
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_selectable_list_item, shoppingList);
                        shopView.setAdapter(arrayAdapter);
                    }
                });
                // BUG: user must click on item in the list before hitting clear for list to clear
                // I believe it has something to do with the variable i passed into OnClickListener
                // User clicks 'Clear List' and list is cleared
                clearList.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        shoppingList.clear();
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_selectable_list_item, shoppingList);
                        shopView.setAdapter(arrayAdapter);
                    }
                });
                // User clicks 'Save List' and list is saved to shared preferences
                saveList.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        saveList(shoppingList, key);
                    }
                });
            }
        });
    }
}
