package com.example.testrecipeapi;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class DishSearch extends AppCompatActivity {

    private TextView mPlateText;
    private Button searchBtn;
    private ArrayList<String> arrayList = new ArrayList<>();
    ListView listView;
    JSONObject object = null;
    JSONArray jArr = null;
    String myResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dishsearch);
        listView = findViewById(R.id.listView);
        mPlateText = findViewById(R.id.plateToSearch);
        searchBtn = findViewById(R.id.searchButton);

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("https://edamam-recipe-search.p.rapidapi.com/search?q=" + mPlateText.getText())
                        .get()
                        .addHeader("x-rapidapi-host", "edamam-recipe-search.p.rapidapi.com")
                        .addHeader("x-rapidapi-key", "5b4a968887msh5c694e10c26e3bep19e01ajsn63e0b5c4c9b3")
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            myResponse = response.body().string();

                            try {
                                object = new JSONObject(myResponse);
                                jArr = object.getJSONArray("hits");
                                object = jArr.getJSONObject(0);
                                object = object.getJSONObject("recipe");
                                jArr = object.getJSONArray("ingredientLines");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            DishSearch.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    for (int i = 0; i < jArr.length(); i++) {
                                        try {
                                            arrayList.add(jArr.getString(i));
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);
                                    listView.setAdapter(arrayAdapter);
                                    arrayList = new ArrayList<>();
                                }
                            });
                        }
                    }
                });
            }
        });
    }
}